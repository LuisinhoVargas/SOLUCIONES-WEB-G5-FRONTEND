export class RolModulo {
  idRolModulo: number;          
  idRol: number;              
  idModulo: number;            
}