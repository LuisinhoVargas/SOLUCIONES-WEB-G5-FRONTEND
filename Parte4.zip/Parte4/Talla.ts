export class Talla {
  idTalla: number;                
  nombreTalla: string;           
  descripcion: string | null;
  estaActivo: boolean;
}