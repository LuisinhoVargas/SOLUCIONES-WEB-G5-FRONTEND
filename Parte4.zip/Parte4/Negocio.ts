export class Negocio {
  idNegocio: number;          // Short
  nombreNegocio: string;
  RUC_negocio: string | null;
  numCelular: string | null;
  direccion: string | null;
}