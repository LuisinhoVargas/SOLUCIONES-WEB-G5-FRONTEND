export class Usuario {
  idUsuario: number;
  nombreUsuario: string;
  correoElectronico: string;      
  contraseniaHash: string;       
  fechaHoraRegistro: Date | string;
  fechaHoraModificacion: Date | string;
  estaActivo: boolean;
}