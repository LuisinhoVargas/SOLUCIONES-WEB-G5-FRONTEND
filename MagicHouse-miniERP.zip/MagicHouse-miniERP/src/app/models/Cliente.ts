export class Cliente {
  idCliente: number;
  nombresCliente: string;
  apellidosCliente: string;
  dni: string;
  numCelular?: string;
  dniDevuelto?: boolean;
  fechaRegistro: Date | string;
  fechaModificacion?: Date | string;
  direccion?: string;
  idEstadoCliente: number;
}
