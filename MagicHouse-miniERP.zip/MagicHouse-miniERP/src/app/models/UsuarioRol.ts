export class UsuarioRol {
  idUsuario: number;
  idRol: number;
}
