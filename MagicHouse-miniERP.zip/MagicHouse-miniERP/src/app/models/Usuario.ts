export class Usuario {
  idUsuario: number;
  nombreUsuario: string;
  clave: string;
  fechaRegistro: Date | string;
  estaActivo: boolean;
}
