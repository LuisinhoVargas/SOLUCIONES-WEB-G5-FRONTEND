export class EstadoCliente {
  idEstadoCliente: number;
  nombreEstadoCliente: string;
  descripcion?: string;
  estaActivo: boolean;
}
